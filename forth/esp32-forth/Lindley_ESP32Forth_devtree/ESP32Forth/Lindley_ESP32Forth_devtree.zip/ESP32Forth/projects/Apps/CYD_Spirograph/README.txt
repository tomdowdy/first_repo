This is a Spirograph app for the 320x240 ILI9341 2.8" display on the CYD
This code is working well.