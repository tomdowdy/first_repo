This is the Earth Quake Map Code for the 320x240 ILI9341 2.8" display from pjrc.com
This code is working well.