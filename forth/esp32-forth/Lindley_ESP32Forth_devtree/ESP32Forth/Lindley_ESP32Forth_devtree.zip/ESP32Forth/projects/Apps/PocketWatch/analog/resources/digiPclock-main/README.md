# digiPclock
digiPclock is a digital pocket clock based on ESP32C3 and GC9A01 with TFT_espi

![1677429239352](https://user-images.githubusercontent.com/59290454/221432257-28760b77-c963-4ed5-8330-7cbce8b4878f.jpeg)

![intro_pock](https://user-images.githubusercontent.com/59290454/221432265-f2b099ac-b7cf-4797-b62b-ad4f66e6c266.jpeg)


![circuit](https://user-images.githubusercontent.com/59290454/221641801-3c04cee9-ce4d-4916-95cb-fd6ef4b093cf.jpg)
